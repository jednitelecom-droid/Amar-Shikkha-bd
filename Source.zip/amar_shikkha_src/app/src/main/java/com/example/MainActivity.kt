package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.Screen
import com.example.ui.ShikkhaViewModel
import com.example.ui.components.ShikkhaBottomNavBar
import com.example.ui.components.ShikkhaTopAppBar
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.ResultScreen
import com.example.ui.screens.SubjectChaptersScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        AmarShikkhaApp()
      }
    }
  }
}

@Composable
fun AmarShikkhaApp(
  viewModel: ShikkhaViewModel = viewModel()
) {
  val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
  val profile by viewModel.studentProfile.collectAsStateWithLifecycle()
  val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
  val selectedChapter by viewModel.selectedChapter.collectAsStateWithLifecycle()

  // Handle system back navigation
  BackHandler(enabled = currentScreen !is Screen.Home) {
    viewModel.navigateBack()
  }

  val title = when (currentScreen) {
    is Screen.Home -> "আমার শিক্ষা বিডি"
    is Screen.SubjectChapters -> selectedSubject.banglaName
    is Screen.LessonDetail -> selectedChapter?.title ?: "পাঠের বিবরণ"
    is Screen.QuizSession -> "বহুনির্বাচনী কুইজ"
    is Screen.QuizResult -> "পরীক্ষার ফলাফল"
    is Screen.ExamHistory -> "ফলাফল তালিকা"
    is Screen.Profile -> "শিক্ষার্থী প্রোফাইল"
  }

  val showBackButton = currentScreen !is Screen.Home && currentScreen !is Screen.ExamHistory && currentScreen !is Screen.Profile
  val showBottomNav = currentScreen is Screen.Home || currentScreen is Screen.ExamHistory || currentScreen is Screen.Profile

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      ShikkhaTopAppBar(
        title = title,
        showBackButton = showBackButton,
        onBackClick = { viewModel.navigateBack() },
        onProfileClick = { viewModel.navigateTo(Screen.Profile) },
        studentName = profile?.studentName ?: ""
      )
    },
    bottomBar = {
      if (showBottomNav) {
        ShikkhaBottomNavBar(
          currentScreen = currentScreen,
          onNavigate = { screen -> viewModel.navigateTo(screen) }
        )
      }
    }
  ) { innerPadding ->
    val modifier = Modifier
      .fillMaxSize()
      .padding(innerPadding)

    when (currentScreen) {
      is Screen.Home -> {
        HomeScreen(
          viewModel = viewModel,
          onNavigateToSubject = { subject ->
            viewModel.selectSubject(subject)
          },
          modifier = modifier
        )
      }

      is Screen.SubjectChapters -> {
        SubjectChaptersScreen(
          viewModel = viewModel,
          onOpenLesson = { chapter ->
            viewModel.openChapter(chapter)
          },
          onStartQuiz = { chapter ->
            viewModel.startQuiz(chapter)
          },
          modifier = modifier
        )
      }

      is Screen.LessonDetail -> {
        LessonDetailScreen(
          viewModel = viewModel,
          onStartQuiz = { chapter ->
            viewModel.startQuiz(chapter)
          },
          modifier = modifier
        )
      }

      is Screen.QuizSession -> {
        QuizScreen(
          viewModel = viewModel,
          onFinishQuiz = {
            // Screen transition handled by ViewModel.finishQuiz()
          },
          modifier = modifier
        )
      }

      is Screen.QuizResult -> {
        ResultScreen(
          viewModel = viewModel,
          onRetryQuiz = {
            val chapter = viewModel.quizState.value.chapter
            if (chapter != null) {
              viewModel.startQuiz(chapter)
            }
          },
          onBackToHome = {
            viewModel.navigateTo(Screen.Home)
          },
          onBackToChapters = {
            viewModel.navigateTo(Screen.SubjectChapters)
          },
          modifier = modifier
        )
      }

      is Screen.ExamHistory -> {
        HistoryScreen(
          viewModel = viewModel,
          onStartExam = {
            viewModel.navigateTo(Screen.Home)
          },
          modifier = modifier
        )
      }

      is Screen.Profile -> {
        ProfileScreen(
          viewModel = viewModel,
          modifier = modifier
        )
      }
    }
  }
}
