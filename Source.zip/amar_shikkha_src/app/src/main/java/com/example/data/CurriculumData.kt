package com.example.data

import com.example.model.Chapter
import com.example.model.ClassGrade
import com.example.model.LessonSection
import com.example.model.Question
import com.example.model.SubjectType

object CurriculumData {

  val chapters: List<Chapter> = listOf(
    // ==========================================
    // CLASS 1 (১ম শ্রেণি)
    // ==========================================
    // 1. Class 1 - Bangla
    Chapter(
      id = "c1_ban_1",
      classGrade = ClassGrade.CLASS_1,
      subjectType = SubjectType.BANGLA,
      chapterNumberBengali = "অধ্যায় ১",
      title = "স্বরবর্ণ ও বর্ণমালা পরিচিতি",
      subtitle = "অ থেকে ঔ পর্যন্ত বর্ণমালা ও তাদের উচ্চারণ শিখি",
      readingMinutes = 5,
      sections = listOf(
        LessonSection(
          title = "স্বরবর্ণ কী?",
          bodyText = "বাংলা ভাষায় যে বর্ণগুলো অন্য কোনো বর্ণের সাহায্য ছাড়া নিজেই নিজে উচ্চারিত হতে পারে, তাদের স্বরবর্ণ বলে। বাংলা বর্ণমালায় মোট ১১টি স্বরবর্ণ রয়েছে।",
          bulletPoints = listOf(
            "অ - অজগর আসছে তেড়ে",
            "আ - আমটি আমি খাব পেড়ে",
            "ই - ইঁদুর ছানা ভয়ে মরে",
            "ঈ - ঈগল পাখি পাছে ধরে",
            "উ - উট চলেছে মুখটি তুলে",
            "ঊ - ঊষা হাসে পূব আকাশে"
          ),
          specialBoxTitle = "মনে রেখো",
          specialBoxContent = "বাংলা ভাষায় স্বরবর্ণ মোট ১১টি। স্বরবর্ণের সংক্ষিপ্ত রূপকে 'কার' বলা হয়। যেমন আকার (া), ই-কার (ি)।"
        ),
        LessonSection(
          title = "ঋ, এ, ঐ, ও, ঔ",
          bodyText = "বাকি স্বরবর্ণগুলোও খুব সুন্দর। এগুলো দিয়েও মজার মজার শব্দ তৈরি হয়।",
          bulletPoints = listOf(
            "ঋ - ঋষি মশাই বসেন পূজায়",
            "এ - এক্কা গাড়ি খুব ছুটেছে",
            "ঐ - ঐরাবত ওই দাঁড়িয়ে আছে",
            "ও - ওল খেলে কিন্তু গলা ধরে",
            "ঔ - ঔষধ খাও সেরে যাবে"
          )
        )
      ),
      questions = listOf(
        Question(
          id = "c1_ban_1_q1",
          questionText = "বাংলা বর্ণমালায় স্বরবর্ণ কয়টি?",
          options = listOf("৯টি", "১০টি", "১১টি", "১২টি"),
          correctIndex = 2,
          explanation = "বাংলা ভাষায় মোট ১১টি স্বরবর্ণ আছে: অ, আ, ই, ঈ, উ, ঊ, ঋ, এ, ঐ, ও, ঔ।"
        ),
        Question(
          id = "c1_ban_1_q2",
          questionText = "'আমটি আমি খাব পেড়ে' - কোন বর্ণ দিয়ে শুরু হয়?",
          options = listOf("অ", "আ", "ই", "উ"),
          correctIndex = 1,
          explanation = "আম শব্দটি 'আ' দিয়ে শুরু হয়।"
        ),
        Question(
          id = "c1_ban_1_q3",
          questionText = "নিচের কোনটি স্বরবর্ণ?",
          options = listOf("ক", "খ", "ঈ", "গ"),
          correctIndex = 2,
          explanation = "ক, খ, গ হলো ব্যঞ্জনবর্ণ এবং 'ঈ' হলো স্বরবর্ণ।"
        ),
        Question(
          id = "c1_ban_1_q4",
          questionText = "স্বরবর্ণের সংক্ষিপ্ত রূপকে কী বলা হয়?",
          options = listOf("ফলা", "কার", "মাত্রা", "যুক্তবর্ণ"),
          correctIndex = 1,
          explanation = "স্বরবর্ণের সংক্ষিপ্ত রূপকে 'কার' বলে, যেমন আকার (া), ই-কার (ি)।"
        )
      )
    ),

    // 2. Class 1 - English
    Chapter(
      id = "c1_eng_1",
      classGrade = ClassGrade.CLASS_1,
      subjectType = SubjectType.ENGLISH,
      chapterNumberBengali = "Lesson 1",
      title = "Alphabet & Words (A to G)",
      subtitle = "Learning English letters with pictures and sounds",
      readingMinutes = 6,
      sections = listOf(
        LessonSection(
          title = "Let's Learn Letters",
          bodyText = "English Alphabet has 26 letters. Let's learn the first few letters with fun words and pictures!",
          bulletPoints = listOf(
            "A is for Apple (আপেল) - An apple a day keeps the doctor away.",
            "B is for Ball (বল) - We play with a ball.",
            "C is for Cat (বিড়াল) - The cat says Meow.",
            "D is for Dog (কুকুর) - The dog wags its tail.",
            "E is for Egg (ডিম) - Eggs give us healthy protein.",
            "F is for Fish (মাছ) - Fish swims in water."
          ),
          specialBoxTitle = "Golden Rule",
          specialBoxContent = "Letters have two forms: Capital letters (A, B, C) and Small letters (a, b, c)."
        )
      ),
      questions = listOf(
        Question(
          id = "c1_eng_1_q1",
          questionText = "Which letter does 'Apple' start with?",
          options = listOf("B", "A", "C", "D"),
          correctIndex = 1,
          explanation = "'Apple' starts with letter 'A'."
        ),
        Question(
          id = "c1_eng_1_q2",
          questionText = "What is the Bengali meaning of 'Fish'?",
          options = listOf("পাখি", "কুকুর", "মাছ", "বিড়াল"),
          correctIndex = 2,
          explanation = "'Fish' মানে হলো মাছ।"
        ),
        Question(
          id = "c1_eng_1_q3",
          questionText = "How many letters are there in the English Alphabet?",
          options = listOf("24", "25", "26", "28"),
          correctIndex = 2,
          explanation = "There are 26 letters in the English alphabet (A to Z)."
        ),
        Question(
          id = "c1_eng_1_q4",
          questionText = "What comes after letter 'C'?",
          options = listOf("B", "D", "E", "F"),
          correctIndex = 1,
          explanation = "In the alphabet sequence, D comes right after C."
        )
      )
    ),

    // 3. Class 1 - Math
    Chapter(
      id = "c1_math_1",
      classGrade = ClassGrade.CLASS_1,
      subjectType = SubjectType.MATH,
      chapterNumberBengali = "অধ্যায় ১",
      title = "সংখ্যা গণনা ও তুলনা (১ থেকে ১০)",
      subtitle = "সহজে ছবি দেখে গণনা ও ছোট-বড় চেনার উপায়",
      readingMinutes = 5,
      sections = listOf(
        LessonSection(
          title = "সংখ্যা পরিচিতি",
          bodyText = "আমরা দৈনন্দিন জীবনে সবকিছু গুনতে সংখ্যা ব্যবহার করি। যেমন: ১টি চাঁদ, ২টি চোখ, ৩টি চাকার রিকশা।",
          bulletPoints = listOf(
            "১ (এক) - আমাদের নাক ১টি",
            "২ (দুই) - আমাদের চোখ ২টি এবং কান ২টি",
            "৩ (তিন) - রিকশার চাকা ৩টি",
            "৪ (চার) - গরুর পা ৪টি",
            "৫ (পাঁচ) - এক হাতে আঙুল ৫টি"
          ),
          specialBoxTitle = "মজার তথ্য",
          specialBoxContent = "যে সংখ্যাটি পরে আসে তা আগের সংখ্যার চেয়ে বড়। যেমন: ৪ হলো ৩ এর চেয়ে বড়।"
        )
      ),
      questions = listOf(
        Question(
          id = "c1_math_1_q1",
          questionText = "আমাদের এক হাতে কয়টি আঙুল থাকে?",
          options = listOf("৪টি", "৫টি", "৬টি", "১০টি"),
          correctIndex = 1,
          explanation = "মানুষের প্রতিটি হাতে ৫টি করে আঙুল থাকে।"
        ),
        Question(
          id = "c1_math_1_q2",
          questionText = "৩ এর ঠিক পরের সংখ্যাটি কোনটি?",
          options = listOf("২", "৪", "৫", "১"),
          correctIndex = 1,
          explanation = "১, ২, ৩ এর পর আসে ৪।"
        ),
        Question(
          id = "c1_math_1_q3",
          questionText = "২ + ৩ সমান কত হয়?",
          options = listOf("৪", "৫", "৬", "৭"),
          correctIndex = 1,
          explanation = "২ এর সাথে ৩ যোগ করলে হয় ৫ (২ + ৩ = ৫)।"
        ),
        Question(
          id = "c1_math_1_q4",
          questionText = "নিচের কোন সংখ্যাটি সবচেয়ে বড়?",
          options = listOf("৩", "৭", "৫", "২"),
          correctIndex = 1,
          explanation = "তালিকার মধ্যে ৭ সংখ্যাটি সবচেয়ে বড়।"
        )
      )
    ),

    // 4. Class 1 - Science
    Chapter(
      id = "c1_sci_1",
      classGrade = ClassGrade.CLASS_1,
      subjectType = SubjectType.SCIENCE,
      chapterNumberBengali = "অধ্যায় ১",
      title = "আমাদের চারপাশের সুন্দর পরিবেশ",
      subtitle = "জীব ও জড় বস্তু চেনা এবং পরিবেশের যত্ন নেওয়া",
      readingMinutes = 5,
      sections = listOf(
        LessonSection(
          title = "জীব ও জড় বস্তু",
          bodyText = "আমাদের চারপাশে যা কিছু আছে সবকিছু নিয়েই আমাদের পরিবেশ। পরিবেশে দুই ধরনের জিনিস দেখতে পাই: জীব এবং জড়।",
          bulletPoints = listOf(
            "জীব: যাদের জীবন আছে, খাবার খায় এবং বড় হয়। যেমন: মানুষ, গাছপালা, গরু, পাখি।",
            "জড়: যাদের জীবন নেই, খাবার খায় না এবং নিজে নিজে চলতে পারে না। যেমন: বই, খাতা, চেয়ার, টেবিল, ইট।"
          ),
          specialBoxTitle = "পরিবেশের যত্ন",
          specialBoxContent = "গাছ আমাদের অক্সিজেন ও ছায়া দেয়। তাই কখনোই গাছের ডাল ভাঙা বা পাতা ছেঁড়া উচিত নয়।"
        )
      ),
      questions = listOf(
        Question(
          id = "c1_sci_1_q1",
          questionText = "নিচের কোনটি জীব?",
          options = listOf("বই", "আমগাছ", "চেয়ার", "কলম"),
          correctIndex = 1,
          explanation = "গাছপালার জীবন আছে এবং তারা বৃদ্ধি পায়, তাই আমগাছ একটি জীব।"
        ),
        Question(
          id = "c1_sci_1_q2",
          questionText = "জড় বস্তুর বৈশিষ্ট্য কোনটি?",
          options = listOf("খাবার খায়", "নিজে নড়াচড়া করে", "জীবন নেই", "শ্বাস নেয়"),
          correctIndex = 2,
          explanation = "জড় বস্তুর জীবন থাকে না এবং এরা খাবার খায় না।"
        ),
        Question(
          id = "c1_sci_1_q3",
          questionText = "গাছপালা আমাদের কী দেয়?",
          options = listOf("অক্সিজেন", "ইট", "কাগজ", "লোহা"),
          correctIndex = 0,
          explanation = "গাছপালা আমাদের বেঁচে থাকার জন্য অপরিহার্য অক্সিজেন গ্যাস দেয়।"
        ),
        Question(
          id = "c1_sci_1_q4",
          questionText = "মাছের শ্বাস নেওয়ার স্থান কোনটি?",
          options = listOf("নাক", "ফুলকা", "পাখনা", "লেজ"),
          correctIndex = 1,
          explanation = "মাছ ফুলকার সাহায্যে পানিতে দ্রবীভূত অক্সিজেন নিয়ে শ্বাস নেয়।"
        )
      )
    ),

    // ==========================================
    // CLASS 2 (২য় শ্রেণি)
    // ==========================================
    // 1. Class 2 - Bangla
    Chapter(
      id = "c2_ban_1",
      classGrade = ClassGrade.CLASS_2,
      subjectType = SubjectType.BANGLA,
      chapterNumberBengali = "অধ্যায় ১",
      title = "আমাদের প্রিয় বাংলাদেশ",
      subtitle = "আমাদের মাতৃভূমি, জাতীয় প্রতীক ও প্রাকৃতিক রূপ",
      readingMinutes = 6,
      sections = listOf(
        LessonSection(
          title = "মাতৃভূমির কথা",
          bodyText = "আমাদের দেশের নাম গণপ্রজাতন্ত্রী বাংলাদেশ। ১৯৭১ সালে নয় মাস রক্তক্ষয়ী মুক্তিযুদ্ধের পর আমরা বিজয় অর্জন করি। আমাদের দেশের রূপ চিরসবুজ।",
          bulletPoints = listOf(
            "জাতীয় ফুল: শাপলা (সাদা শাপলা)",
            "জাতীয় ফল: কাঁঠাল",
            "জাতীয় পশু: রয়েল বেঙ্গল টাইগার",
            "জাতীয় পাখি: দোয়েল",
            "জাতীয় মাছ: ইলিশ"
          ),
          specialBoxTitle = "স্মরণ করি",
          specialBoxContent = "আমাদের জাতীয় সংগীতের রচয়িতা হলেন বিশ্বকবি রবীন্দ্রনাথ ঠাকুর - 'আমার সোনার বাংলা, আমি তোমায় ভালোবাসি'।"
        )
      ),
      questions = listOf(
        Question(
          id = "c2_ban_1_q1",
          questionText = "বাংলাদেশের জাতীয় ফুলের নাম কী?",
          options = listOf("গোলাপ", "শাপলা", "বেলি", "জবা"),
          correctIndex = 1,
          explanation = "বাংলাদেশের জাতীয় ফুল হলো সাদা শাপলা।"
        ),
        Question(
          id = "c2_ban_1_q2",
          questionText = "আমাদের জাতীয় পাখি কোনটি?",
          options = listOf("টিয়া", "ময়না", "দোয়েল", "কোকিল"),
          correctIndex = 2,
          explanation = "দোয়েল হলো বাংলাদেশের জাতীয় পাখি।"
        ),
        Question(
          id = "c2_ban_1_q3",
          questionText = "আমাদের জাতীয় মাছের নাম কী?",
          options = listOf("রুই", "কাতলা", "ইলিশ", "মাগুর"),
          correctIndex = 2,
          explanation = "স্বাদু ও সুস্বাদু ইলিশ মাছ আমাদের জাতীয় মাছ।"
        ),
        Question(
          id = "c2_ban_1_q4",
          questionText = "বাংলাদেশের জাতীয় সংগীতের রচয়িতা কে?",
          options = listOf("কাজী নজরুল ইসলাম", "রবীন্দ্রনাথ ঠাকুর", "জসীমউদ্দীন", "সুকান্ত ভট্টাচার্য"),
          correctIndex = 1,
          explanation = "বিশ্বকবি রবীন্দ্রনাথ ঠাকুর আমাদের জাতীয় সংগীত 'আমার সোনার বাংলা' রচনা করেছেন।"
        )
      )
    ),

    // 2. Class 2 - English
    Chapter(
      id = "c2_eng_1",
      classGrade = ClassGrade.CLASS_2,
      subjectType = SubjectType.ENGLISH,
      chapterNumberBengali = "Lesson 1",
      title = "Days of the Week & Colors",
      subtitle = "Learn the 7 days and rainbow colors in English",
      readingMinutes = 6,
      sections = listOf(
        LessonSection(
          title = "Seven Days of the Week",
          bodyText = "There are 7 days in a week. Let us learn their names in English and Bangla:",
          bulletPoints = listOf(
            "Saturday (শনিবার) - First day of the week in Bangladesh",
            "Sunday (রবিবার)",
            "Monday (সোমবার)",
            "Tuesday (মঙ্গলবার)",
            "Wednesday (বুধবার)",
            "Thursday (বৃহস্পতিবার)",
            "Friday (শুক্রবার) - Our weekly holiday!"
          ),
          specialBoxTitle = "Rainbow Colors",
          specialBoxContent = "Red (লাল), Blue (নীল), Green (সবুজ), Yellow (হলুদ), Orange (কমলা), Violet (বেগুনী)."
        )
      ),
      questions = listOf(
        Question(
          id = "c2_eng_1_q1",
          questionText = "How many days are there in a week?",
          options = listOf("5", "6", "7", "8"),
          correctIndex = 2,
          explanation = "There are 7 days in a week."
        ),
        Question(
          id = "c2_eng_1_q2",
          questionText = "What day comes after Monday?",
          options = listOf("Sunday", "Tuesday", "Wednesday", "Thursday"),
          correctIndex = 1,
          explanation = "Tuesday comes right after Monday."
        ),
        Question(
          id = "c2_eng_1_q3",
          questionText = "What is the English name of 'সবুজ'?",
          options = listOf("Red", "Blue", "Green", "White"),
          correctIndex = 2,
          explanation = "Green means সবুজ in Bengali."
        ),
        Question(
          id = "c2_eng_1_q4",
          questionText = "Which day is the weekly holiday in our school?",
          options = listOf("Monday", "Friday", "Wednesday", "Tuesday"),
          correctIndex = 1,
          explanation = "Friday (শুক্রবার) is our regular weekly weekend holiday."
        )
      )
    ),

    // 3. Class 2 - Math
    Chapter(
      id = "c2_math_1",
      classGrade = ClassGrade.CLASS_2,
      subjectType = SubjectType.MATH,
      chapterNumberBengali = "অধ্যায় ১",
      title = "নামতা ও গুণের প্রাথমিক ধারণা",
      subtitle = "সহজে গুণের নিয়ম এবং ২ ও ৩ এর নামতা মুখস্থ করা",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "গুণ মানে কী?",
          bodyText = "গুণ হলো একই সংখ্যা বারবার যোগ করার সংক্ষিপ্ত সহজ উপায়। যেমন: ৩টি ঝুড়িতে ২টি করে আম থাকলে মোট আম = ২ + ২ + ২ = ৬টি। সংক্ষেপে: ২ × ৩ = ৬।",
          bulletPoints = listOf(
            "২ × ১ = ২",
            "২ × ২ = ৪",
            "২ × ৩ = ৬",
            "২ × ৪ = ৮",
            "২ × ৫ = ১০"
          ),
          specialBoxTitle = "গুণের সূত্র",
          specialBoxContent = "যেকোনো সংখ্যাকে শূন্য (০) দিয়ে গুণ করলে গুণফল সর্বদা শূন্য (০) হয়। যেমন: ৫ × ০ = ০।"
        )
      ),
      questions = listOf(
        Question(
          id = "c2_math_1_q1",
          questionText = "২ × ৪ সমান কত?",
          options = listOf("৬", "৭", "৮", "১০"),
          correctIndex = 2,
          explanation = "২ কে ৪ দিয়ে গুণ করলে হয় ৮ (২ × ৪ = ৮)।"
        ),
        Question(
          id = "c2_math_1_q2",
          questionText = "যেকোনো সংখ্যাকে ০ দিয়ে গুণ করলে ফল কত হয়?",
          options = listOf("১", "০", "সেই সংখ্যাটি", "১০"),
          correctIndex = 1,
          explanation = "যেকোনো সংখ্যাকে শূন্য দ্বারা গুণ করলে গুণফল শূন্য (০) হয়।"
        ),
        Question(
          id = "c2_math_1_q3",
          questionText = "একটি রিকশার ৩টি চাকা। ২টি রিকশার মোট চাকা কয়টি?",
          options = listOf("৫টি", "৬টি", "৭টি", "৮টি"),
          correctIndex = 1,
          explanation = "৩ × ২ = ৬টি চাকা।"
        ),
        Question(
          id = "c2_math_1_q4",
          questionText = "১০ এর অর্ধেক কত?",
          options = listOf("৪", "৫", "৬", "২"),
          correctIndex = 1,
          explanation = "১০ কে ২ ভাগ করলে হয় ৫ (১০ ÷ ২ = ৫)।"
        )
      )
    ),

    // 4. Class 2 - Science
    Chapter(
      id = "c2_sci_1",
      classGrade = ClassGrade.CLASS_2,
      subjectType = SubjectType.SCIENCE,
      chapterNumberBengali = "অধ্যায় ১",
      title = "উদ্ভিদ ও প্রাণী পরিচিতি",
      subtitle = "উদ্ভিদের অংশ এবং প্রাণীদের বাসস্থান",
      readingMinutes = 6,
      sections = listOf(
        LessonSection(
          title = "উদ্ভিদের প্রধান অংশগুলো",
          bodyText = "একটি সম্পূর্ণ উদ্ভিদের প্রধান পাঁচটি অংশ থাকে: মূল বা শিকড়, কাণ্ড, পাতা, ফুল এবং ফল।",
          bulletPoints = listOf(
            "মূল: মাটির নিচে থাকে এবং গাছকে শক্ত করে ধরে রাখে।",
            "কাণ্ড: গাছের ডালপালা ও পাতাকে খাড়া রাখে।",
            "পাতা: সূর্যের আলোর সাহায্যে গাছের খাবার তৈরি করে।",
            "ফুল ও ফল: বীজ তৈরি করে বংশবৃদ্ধি করে।"
          ),
          specialBoxTitle = "সবুজ পাতা",
          specialBoxContent = "উদ্ভিদের পাতাকে উদ্ভিদের 'রান্নাঘর' বলা হয়, কারণ পাতা সূর্যের আলো ব্যবহার করে সালোকসংশ্লেষণ প্রক্রিয়ায় খাদ্য তৈরি করে।"
        )
      ),
      questions = listOf(
        Question(
          id = "c2_sci_1_q1",
          questionText = "গাছের কোন অংশ মাটির নিচে থাকে?",
          options = listOf("পাতা", "ফুল", "মূল বা শিকড়", "ফল"),
          correctIndex = 2,
          explanation = "মূল বা শিকড় মাটির নিচে থেকে পানি ও পুষ্টি শোষণ করে।"
        ),
        Question(
          id = "c2_sci_1_q2",
          questionText = "গাছের খাবার তৈরি হয় কোথায়?",
          options = listOf("মূলে", "কাণ্ডে", "পাতায়", "ফলে"),
          correctIndex = 2,
          explanation = "সূর্যের আলোয় সবুজ পাতায় উদ্ভিদের খাদ্য তৈরি হয়।"
        ),
        Question(
          id = "c2_sci_1_q3",
          questionText = "নিচের কোনটি পানিতে বাস করে?",
          options = listOf("বাঘ", "গরু", "মাছ", "দোয়েল"),
          correctIndex = 2,
          explanation = "মাছ জলজ প্রাণী এবং এরা পানিতে বাস করে।"
        ),
        Question(
          id = "c2_sci_1_q4",
          questionText = "পাখির শরীর কী দিয়ে ঢাকা থাকে?",
          options = listOf("পশম", "আইঁশ", "পালক", "চামড়া"),
          correctIndex = 2,
          explanation = "পাখির শরীর হালকা ও নরম পালক দিয়ে ঢাকা থাকে যা তাকে উড়তে সাহায্য করে।"
        )
      )
    ),

    // ==========================================
    // CLASS 3 (৩য় শ্রেণি)
    // ==========================================
    // 1. Class 3 - Bangla
    Chapter(
      id = "c3_ban_1",
      classGrade = ClassGrade.CLASS_3,
      subjectType = SubjectType.BANGLA,
      chapterNumberBengali = "অধ্যায় ১",
      title = "রাজা ও তার তিন কন্যা",
      subtitle = "ভালোবাসা ও স্নেহের শিক্ষণীয় বিখ্যাত রূপকথা",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "গল্পের মূল শিক্ষা",
          bodyText = "এক দেশে এক রাজা ছিলেন। তার ছিল তিন কন্যা: শিমুল, বকুল আর পারুল। রাজা তাদের জিজ্ঞেস করলেন, কে তাকে কেমন ভালোবাসে।",
          bulletPoints = listOf(
            "বড় মেয়ে শিমুল বলল: বাবা, আমি তোমাকে চিনির মতো ভালোবাসি।",
            "মেজো মেয়ে বকুল বলল: বাবা, আমি তোমাকে মিষ্টির মতো ভালোবাসি।",
            "ছোট মেয়ে পারুল বলল: বাবা, আমি তোমাকে নুনের (লবণের) মতো ভালোবাসি।"
          ),
          specialBoxTitle = "শিক্ষা",
          specialBoxContent = "রাজা রেগে পারুলকে বনবাসে পাঠালেন। পরে লবণ ছাড়া রান্না খেয়ে বুঝতে পারলেন, নুন ছাড়া খাবার কোনো স্বাদ থাকে না। পারুলের ভালোবাসাই সবচেয়ে গভীর ও খাঁটি ছিল।"
        )
      ),
      questions = listOf(
        Question(
          id = "c3_ban_1_q1",
          questionText = "ছোট মেয়ে পারুল রাজাকে কিসের মতো ভালোবাসত?",
          options = listOf("চিনির মতো", "মিষ্টির মতো", "নুনের মতো", "মধুর মতো"),
          correctIndex = 2,
          explanation = "পারুল রাজাকে নুনের মতো ভালোবাসার কথা বলেছিল।"
        ),
        Question(
          id = "c3_ban_1_q2",
          questionText = "রাজার বড় মেয়ের নাম কী ছিল?",
          options = listOf("বকুল", "পারুল", "শিমুল", "চম্পা"),
          correctIndex = 2,
          explanation = "রাজার বড় মেয়ের নাম ছিল শিমুল।"
        ),
        Question(
          id = "c3_ban_1_q3",
          questionText = "খাবারে কোন উপাদান না দিলে কোনো স্বাদ লাগে না?",
          options = listOf("চিনি", "লবণ বা নুন", "হলুদ", "মরিচ"),
          correctIndex = 1,
          explanation = "লবণ ছাড়া সব খাবারই বিস্বাদ মনে হয়।"
        ),
        Question(
          id = "c3_ban_1_q4",
          questionText = "গল্পটি থেকে আমরা কী শিখতে পারি?",
          options = listOf("রাগ করা ভালো", "চাটুকারিতা ভালো", "সত্যিকারের মূল্য বোঝা উচিত", "মিষ্টি খাওয়াই শ্রেয়"),
          correctIndex = 2,
          explanation = "বাহ্যিক মিষ্টি কথার চেয়ে জীবনের খাঁটি প্রয়োজনীয় জিনিসের মূল্য বোঝা জরুরি।"
        )
      )
    ),

    // 2. Class 3 - English
    Chapter(
      id = "c3_eng_1",
      classGrade = ClassGrade.CLASS_3,
      subjectType = SubjectType.ENGLISH,
      chapterNumberBengali = "Lesson 1",
      title = "Parts of Speech: Noun & Verb",
      subtitle = "Understanding Naming words and Doing words with examples",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "What is a Noun?",
          bodyText = "A Noun is the name of any person, place, animal, or thing.",
          bulletPoints = listOf(
            "Person: Rahat, Teacher, Father",
            "Place: Dhaka, School, Garden",
            "Animal: Tiger, Cow, Bird",
            "Thing: Pen, Book, Chair"
          ),
          specialBoxTitle = "What is a Verb?",
          specialBoxContent = "A Verb is an action word that describes what someone is doing. Examples: play, read, write, eat, run."
        )
      ),
      questions = listOf(
        Question(
          id = "c3_eng_1_q1",
          questionText = "Which one of the following is a Noun?",
          options = listOf("Run", "Dhaka", "Slowly", "Eat"),
          correctIndex = 1,
          explanation = "'Dhaka' is the name of a city, so it is a Noun."
        ),
        Question(
          id = "c3_eng_1_q2",
          questionText = "Find the Verb in: 'The boy reads a book.'",
          options = listOf("The", "boy", "reads", "book"),
          correctIndex = 2,
          explanation = "'reads' is an action word showing what the boy does, hence it is a Verb."
        ),
        Question(
          id = "c3_eng_1_q3",
          questionText = "What kind of word is 'School'?",
          options = listOf("Noun", "Verb", "Adjective", "Preposition"),
          correctIndex = 0,
          explanation = "'School' is a place name, so it is a Noun."
        ),
        Question(
          id = "c3_eng_1_q4",
          questionText = "Choose the correct sentence:",
          options = listOf("Birds fly in the sky.", "Birds flies in the sky.", "Bird flying in sky.", "Birds are fly."),
          correctIndex = 0,
          explanation = "For plural subject 'Birds', the base verb form 'fly' is correct."
        )
      )
    ),

    // 3. Class 3 - Math
    Chapter(
      id = "c3_math_1",
      classGrade = ClassGrade.CLASS_3,
      subjectType = SubjectType.MATH,
      chapterNumberBengali = "অধ্যায় ১",
      title = "চার অঙ্কের সংখ্যা ও স্থানীয় মান",
      subtitle = "একক, দশক, শতক এবং হাজার চেনা ও মান নির্ণয়",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "স্থানীয় মান কাকে বলে?",
          bodyText = "কোনো সংখ্যায় কোনো অঙ্ক যে স্থানে অবস্থান করে তার ওপর নির্ভর করে তার যে মান হয়, তাকে স্থানীয় মান বলে।",
          bulletPoints = listOf(
            "একক: ১ গুণ (যেমন: ৫ এর মান ৫)",
            "দশক: ১০ গুণ (যেমন: ৩ দশক মানে ৩০)",
            "শতক: ১০০ গুণ (যেমন: ৭ শতক মানে ৭০০)",
            "হাজার: ১০০০ গুণ (যেমন: ৪ হাজার মানে ৪০০০)"
          ),
          specialBoxTitle = "উদাহরণ",
          specialBoxContent = "৩,৫২৪ সংখ্যাটিতে: ৩ এর স্থানীয় মান ৩০০০, ৫ এর মান ৫০০, ২ এর মান ২০, এবং ৪ এর মান ৪।"
        )
      ),
      questions = listOf(
        Question(
          id = "c3_math_1_q1",
          questionText = "৪,৫২০ সংখ্যাটিতে ৫ এর স্থানীয় মান কত?",
          options = listOf("৫", "৫০", "৫০০", "৫০০০"),
          correctIndex = 2,
          explanation = "৫ শতকের ঘরে আছে, তাই এর স্থানীয় মান ৫০০।"
        ),
        Question(
          id = "c3_math_1_q2",
          questionText = "তিন অঙ্কের বৃহত্তম সংখ্যা কোনটি?",
          options = listOf("১০০", "৯৯৯", "৯৯", "১০০০"),
          correctIndex = 1,
          explanation = "তিন অঙ্কের বৃহত্তম সংখ্যা হলো ৯৯৯।"
        ),
        Question(
          id = "c3_math_1_q3",
          questionText = "৭ শতক এবং ৫ একক মিলে কত হয়?",
          options = listOf("৭৫", "৭০৫", "৭৫০", "৭০০৫"),
          correctIndex = 1,
          explanation = "৭ শতক = ৭০০ এবং ৫ একক = ৫, মোট = ৭০৫।"
        ),
        Question(
          id = "c3_math_1_q4",
          questionText = "৩৫০ এর সাথে ১৫০ যোগ করলে কত হবে?",
          options = listOf("৪০০", "৪৫০", "৫০০", "৫৫"),
          correctIndex = 2,
          explanation = "৩৫০ + ১৫০ = ৫০০।"
        )
      )
    ),

    // 4. Class 3 - Science
    Chapter(
      id = "c3_sci_1",
      classGrade = ClassGrade.CLASS_3,
      subjectType = SubjectType.SCIENCE,
      chapterNumberBengali = "অধ্যায় ১",
      title = "মেরুদণ্ডী ও অমেরুদণ্ডী প্রাণী",
      subtitle = "প্রাণিজগতের শ্রেণিবিন্যাস ও বৈশিষ্ট্য",
      readingMinutes = 6,
      sections = listOf(
        LessonSection(
          title = "মেরুদণ্ড কী?",
          bodyText = "আমাদের পিঠের মাঝামাঝি শক্ত লম্বা যে হাড় অনুভব করা যায়, তাকে মেরুদণ্ড বলে। মেরুদণ্ডের ওপর ভিত্তি করে প্রাণীকে দুই ভাগে ভাগ করা যায়:",
          bulletPoints = listOf(
            "মেরুদণ্ডী প্রাণী: যাদের মেরুদণ্ড আছে। যেমন: মানুষ, মাছ, ব্যাঙ, পাখি, সাপ, গরু।",
            "অমেরুদণ্ডী প্রাণী: যাদের মেরুদণ্ড নেই। যেমন: কেঁচো, মশা, মাছি, প্রজাপতি, চিংড়ি, শামুক।"
          ),
          specialBoxTitle = "জেনে রাখো",
          specialBoxContent = "চিংড়ি দেখতে মাছের মতো মনে হলেও এটি আসলে অমেরুদণ্ডী সন্ধিপদী প্রাণী।"
        )
      ),
      questions = listOf(
        Question(
          id = "c3_sci_1_q1",
          questionText = "নিচের কোনটি মেরুদণ্ডী প্রাণী?",
          options = listOf("মশা", "কেঁচো", "ব্যাঙ", "প্রজাপতি"),
          correctIndex = 2,
          explanation = "ব্যাঙের পিঠে শক্ত মেরুদণ্ড রয়েছে, তাই ব্যাঙ উভচর মেরুদণ্ডী প্রাণী।"
        ),
        Question(
          id = "c3_sci_1_q2",
          questionText = "নিচের কোনটির মেরুদণ্ড নেই?",
          options = listOf("মাছ", "চিংড়ি", "সাপ", "কুকুর"),
          correctIndex = 1,
          explanation = "চিংড়ির পিঠে কোনো মেরুদণ্ড নেই, তাই এটি অমেরুদণ্ডী প্রাণী।"
        ),
        Question(
          id = "c3_sci_1_q3",
          questionText = "স্তন্যপায়ী প্রাণীর প্রধান বৈশিষ্ট্য কী?",
          options = listOf("ডিম পাড়ে", "মায়ের দুধ পান করে বড় হয়", "পানিতে শ্বাস নেয়", "পালক থাকে"),
          correctIndex = 1,
          explanation = "স্তন্যপায়ী প্রাণীরা সরাসরি বাচ্চা প্রসব করে এবং শাবকরা মায়ের দুধ পান করে।"
        ),
        Question(
          id = "c3_sci_1_q4",
          questionText = "সাপ কোন শ্রেণির প্রাণী?",
          options = listOf("স্তন্যপায়ী", "উভচর", "সরীসৃপ", "পাখি"),
          correctIndex = 2,
          explanation = "সাপ বুকে ভর দিয়ে চলে, তাই এরা সরীসৃপ শ্রেণির মেরুদণ্ডী প্রাণী।"
        )
      )
    ),

    // ==========================================
    // CLASS 4 (৪র্থ শ্রেণি)
    // ==========================================
    // 1. Class 4 - Bangla
    Chapter(
      id = "c4_ban_1",
      classGrade = ClassGrade.CLASS_4,
      subjectType = SubjectType.BANGLA,
      chapterNumberBengali = "অধ্যায় ১",
      title = "বীরশ্রেষ্ঠদের বীরত্বগাথা",
      subtitle = "১৯৭১ সালের মুক্তিযুদ্ধে সাতজন বীরশ্রেষ্ঠের অবদান",
      readingMinutes = 8,
      sections = listOf(
        LessonSection(
          title = "বীরশ্রেষ্ঠ উপাধি",
          bodyText = "১৯৭১ সালের মহান মুক্তিযুদ্ধে অতুলনীয় সাহসিকতা ও আত্মত্যাগের জন্য সাতজন অমর মুক্তিযোদ্ধাকে সর্বোচ্চ সামরিক খেতাব 'বীরশ্রেষ্ঠ' প্রদান করা হয়।",
          bulletPoints = listOf(
            "বীরশ্রেষ্ঠ ক্যাপ্টেন মহিউদ্দিন জাহাঙ্গীর",
            "বীরশ্রেষ্ঠ ল্যান্স নায়েক নূর মোহাম্মদ শেখ",
            "বীরশ্রেষ্ঠ সিপাহী মোস্তফা কামাল",
            "বীরশ্রেষ্ঠ ফ্লাইট লেফটেন্যান্ট মতিউর রহমান",
            "বীরশ্রেষ্ঠ ইঞ্জিন রুম আর্টিফিসার মোহাম্মদ রুহুল আমিন",
            "বীরশ্রেষ্ঠ ল্যান্স নায়েক মুন্সী আব্দুর রউফ",
            "বীরশ্রেষ্ঠ সিপাহী হামিদুর রহমান"
          ),
          specialBoxTitle = "গর্বিত ইতিহাস",
          specialBoxContent = "জাতির এই সাত সূর্যসন্তান দেশের স্বাধীনতার জন্য নিজের অমূল্য জীবন উৎসর্গ করেছেন। আমরা তাদের চিরকাল শ্রদ্ধার সাথে স্মরণ করব।"
        )
      ),
      questions = listOf(
        Question(
          id = "c4_ban_1_q1",
          questionText = "মুক্তিযুদ্ধে কতজনকে 'বীরশ্রেষ্ঠ' খেতাব দেওয়া হয়?",
          options = listOf("৫ জন", "৬ জন", "৭ জন", "১১ জন"),
          correctIndex = 2,
          explanation = "১৯৭১ সালের মুক্তিযুদ্ধে সর্বোচ্চ বীরত্বের জন্য ৭ জনকে বীরশ্রেষ্ঠ উপাধি দেওয়া হয়।"
        ),
        Question(
          id = "c4_ban_1_q2",
          questionText = "বীরশ্রেষ্ঠ মতিউর রহমান কোন বাহিনীর কর্মকর্তা ছিলেন?",
          options = listOf("সেনাবাহিনী", "বিমানবাহিনী", "নৌবাহিনী", "পুলিশ"),
          correctIndex = 1,
          explanation = "ফ্লাইট লেফটেন্যান্ট মতিউর রহমান পাকিস্তান বিমানবাহিনীতে কর্মরত ছিলেন এবং বিমান নিয়ে মুক্তিযুদ্ধে যোগ দিতে চেয়েছিলেন।"
        ),
        Question(
          id = "c4_ban_1_q3",
          questionText = "মুক্তিযুদ্ধে সর্বোচ্চ সামরিক পদক কোনটি?",
          options = listOf("বীর প্রতীক", "বীর উত্তম", "বীর বিক্রম", "বীরশ্রেষ্ঠ"),
          correctIndex = 3,
          explanation = "বীরশ্রেষ্ঠ হলো বাংলাদেশের সর্বোচ্চ সামরিক সাহসিকতা পুরস্কার।"
        ),
        Question(
          id = "c4_ban_1_q4",
          questionText = "আমাদের বিজয় দিবস কবে পালিত হয়?",
          options = listOf("২৬ মার্চ", "২১ ফেব্রুয়ারি", "১৬ ডিসেম্বর", "১৫ আগস্ট"),
          correctIndex = 2,
          explanation = "১৬ ডিসেম্বর ১৯৭১ সালে আমরা পাকিস্তানি বাহিনীর বিরুদ্ধে চূড়ান্ত বিজয় অর্জন করি।"
        )
      )
    ),

    // 2. Class 4 - English
    Chapter(
      id = "c4_eng_1",
      classGrade = ClassGrade.CLASS_4,
      subjectType = SubjectType.ENGLISH,
      chapterNumberBengali = "Lesson 1",
      title = "Tenses: Present, Past & Future",
      subtitle = "Learning time of action and sentence formation",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "What is a Tense?",
          bodyText = "Tense shows the time of an action. There are three main tenses in English grammar:",
          bulletPoints = listOf(
            "Present Tense (বর্তমান কাল): Something happening now. (Example: I eat rice.)",
            "Past Tense (অতীত কাল): Something already happened. (Example: I ate rice yesterday.)",
            "Future Tense (ভবিষ্যৎ কাল): Something that will happen. (Example: I will eat rice tomorrow.)"
          ),
          specialBoxTitle = "Quick Verb Forms",
          specialBoxContent = "Go -> Went -> Gone | Do -> Did -> Done | Play -> Played -> Played"
        )
      ),
      questions = listOf(
        Question(
          id = "c4_eng_1_q1",
          questionText = "What is the past tense of 'Go'?",
          options = listOf("Gone", "Went", "Going", "Goes"),
          correctIndex = 1,
          explanation = "The past simple form of 'go' is 'went'."
        ),
        Question(
          id = "c4_eng_1_q2",
          questionText = "'I will visit my grandmother tomorrow.' Which tense is this?",
          options = listOf("Present Tense", "Past Tense", "Future Tense", "Continuous"),
          correctIndex = 2,
          explanation = "'will visit' and 'tomorrow' indicate Future Tense."
        ),
        Question(
          id = "c4_eng_1_q3",
          questionText = "Choose the correct past tense sentence:",
          options = listOf("She write a letter.", "She wrote a letter.", "She writing a letter.", "She written a letter."),
          correctIndex = 1,
          explanation = "'wrote' is the correct past simple form of 'write'."
        ),
        Question(
          id = "c4_eng_1_q4",
          questionText = "Which helping verb is used for Future Tense?",
          options = listOf("Is", "Was", "Will", "Has"),
          correctIndex = 2,
          explanation = "'Will' or 'Shall' is used to form future tense sentences."
        )
      )
    ),

    // 3. Class 4 - Math
    Chapter(
      id = "c4_math_1",
      classGrade = ClassGrade.CLASS_4,
      subjectType = SubjectType.MATH,
      chapterNumberBengali = "অধ্যায় ১",
      title = "ভগ্নাংশের ধারণা ও তুলনা",
      subtitle = "লব, হর ও সমতুল ভগ্নাংশ বোঝার সহজ কৌশল",
      readingMinutes = 8,
      sections = listOf(
        LessonSection(
          title = "ভগ্নাংশ কী?",
          bodyText = "একটি সম্পূর্ণ বস্তুকে কয়েকটি সমান অংশে ভাগ করে তার কিছু অংশ নিলে তা ভগ্নাংশ হয়।",
          bulletPoints = listOf(
            "ভগ্নাংশের উপরের সংখ্যাটিকে 'লব' (Numerator) বলে।",
            "ভগ্নাংশের নিচের সংখ্যাটিকে 'হর' (Denominator) বলে।",
            "প্রকৃত ভগ্নাংশ: যে ভগ্নাংশের লব হরের চেয়ে ছোট (যেমন: ২/৩)।",
            "অপ্রকৃত ভগ্নাংশ: যে ভগ্নাংশের লব হরের সমান বা বড় (যেমন: ৫/৩)।"
          ),
          specialBoxTitle = "সহজ সূত্র",
          specialBoxContent = "হর একই হলে, যে ভগ্নাংশের লব বড় সেই ভগ্নাংশটি বড়। যেমন: ৩/৫ হলো ২/৫ এর চেয়ে বড়।"
        )
      ),
      questions = listOf(
        Question(
          id = "c4_math_1_q1",
          questionText = "৩/৪ ভগ্নাংশটিতে 'হর' কোনটি?",
          options = listOf("৩", "৪", "৭", "১"),
          correctIndex = 1,
          explanation = "ভগ্নাংশের নিচের সংখ্যাটিকে হর বলে, তাই এখানে হর হলো ৪।"
        ),
        Question(
          id = "c4_math_1_q2",
          questionText = "নিচের কোনটি প্রকৃত ভগ্নাংশ?",
          options = listOf("৫/২", "৭/৩", "৩/৫", "৪/৪"),
          correctIndex = 2,
          explanation = "যে ভগ্নাংশে লব হরের চেয়ে ছোট তাকে প্রকৃত ভগ্নাংশ বলে (৩ < ৫)।"
        ),
        Question(
          id = "c4_math_1_q3",
          questionText = "১/৪ + ২/৪ সমান কত?",
          options = listOf("৩/৮", "৩/৪", "২/৪", "১/২"),
          correctIndex = 1,
          explanation = "হর একই থাকলে লবদ্বয় যোগ করতে হয়: (১ + ২)/৪ = ৩/৪।"
        ),
        Question(
          id = "c4_math_1_q4",
          questionText = "১/২ এর সমতুল ভগ্নাংশ কোনটি?",
          options = listOf("২/৪", "১/৩", "৩/৫", "২/৩"),
          correctIndex = 0,
          explanation = "১ এবং ২ উভয়কে ২ দ্বারা গুণ করলে হয় ২/৪, যা ১/২ এর সমতুল।"
        )
      )
    ),

    // 4. Class 4 - Science
    Chapter(
      id = "c4_sci_1",
      classGrade = ClassGrade.CLASS_4,
      subjectType = SubjectType.SCIENCE,
      chapterNumberBengali = "অধ্যায় ১",
      title = "খাদ্য ও পুষ্টি উপাদান",
      subtitle = "সুষম খাদ্য, ভিটামিন এবং খনিজ লবণের প্রয়োজনীয়তা",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "খাদ্যের প্রধান উপাদান কয়টি?",
          bodyText = "আমরা শরীর সুস্থ, সবল ও রোগমুক্ত রাখতে খাবার খাই। খাদ্যের প্রধান উপাদান ছয়টি:",
          bulletPoints = listOf(
            "১. শর্করা (ভাত, রুটি, আলু) - শক্তি জোগায়",
            "২. আমিষ (মাছ, মাংস, ডিম, ডাল) - শরীর গঠন ও বৃদ্ধি করে",
            "৩. স্নেহ বা চর্বি (তেল, ঘি, মাখন) - তাপ ও শক্তি জোগায়",
            "৪. ভিটামিন (শাকসবজি, ফলমূল) - রোগ প্রতিরোধ ক্ষমতা বাড়ায়",
            "৫. খনিজ লবণ (দুধ, শাকসবজি, আয়োডিনযুক্ত লবণ) - হাড় ও দাঁত মজবুত করে",
            "৬. পানি - খাদ্য হজম ও রক্ত সঞ্চালনে সাহায্য করে"
          ),
          specialBoxTitle = "জরুরি পুষ্টি",
          specialBoxContent = "ভিটামিন 'এ' এর অভাবে রাতকানা রোগ হয়। ছোট মাছ, গাজর ও পাকা পেঁপেতে প্রচুর ভিটামিন 'এ' থাকে।"
        )
      ),
      questions = listOf(
        Question(
          id = "c4_sci_1_q1",
          questionText = "খাদ্যের প্রধান উপাদান কয়টি?",
          options = listOf("৪টি", "৫টি", "৬টি", "৭টি"),
          correctIndex = 2,
          explanation = "খাদ্যের প্রধান উপাদান ৬টি: শর্করা, আমিষ, স্নেহ, ভিটামিন, খনিজ লবণ ও পানি।"
        ),
        Question(
          id = "c4_sci_1_q2",
          questionText = "আমাদের শরীরের বৃদ্ধি ও ক্ষয়পূরণ করে কোন উপাদান?",
          options = listOf("শর্করা", "আমিষ", "স্নেহ", "পানি"),
          correctIndex = 1,
          explanation = "আমিষ (মাছ, মাংস, ডিম, ডাল) মাংসপেশি গঠন ও শারীরিক বৃদ্ধি ঘটায়।"
        ),
        Question(
          id = "c4_sci_1_q3",
          questionText = "ভিটামিন 'সি' পাওয়া যায় কোন খাবারে?",
          options = listOf("ভাত", "লেবু ও আমলকী", "ঘি", "মাংস"),
          correctIndex = 1,
          explanation = "টক জাতীয় ফল যেমন লেবু, আমলকী ও পেয়ারায় প্রচুর ভিটামিন সি থাকে।"
        ),
        Question(
          id = "c4_sci_1_q4",
          questionText = "কোন ভিটামিনের অভাবে রাতকানা রোগ হয়?",
          options = listOf("ভিটামিন এ", "ভিটামিন বি", "ভিটামিন সি", "ভিটামিন ডি"),
          correctIndex = 0,
          explanation = "ভিটামিন 'এ' এর অভাবে চোখের রাতকানা রোগ দেখা দেয়।"
        )
      )
    ),

    // ==========================================
    // CLASS 5 (৫ম শ্রেণি - প্রাথমিক সমাপনী)
    // ==========================================
    // 1. Class 5 - Bangla
    Chapter(
      id = "c5_ban_1",
      classGrade = ClassGrade.CLASS_5,
      subjectType = SubjectType.BANGLA,
      chapterNumberBengali = "অধ্যায় ১",
      title = "এই দেশ এই মানুষ",
      subtitle = "বাংলাদেশের বৈচিত্র্যময় সম্প্রদায়, উৎসব ও সংস্কৃতি",
      readingMinutes = 8,
      sections = listOf(
        LessonSection(
          title = "বৈচিত্র্যের মাঝে ঐক্য",
          bodyText = "বাংলাদেশের সবচেয়ে বড় গৌরব হলো এ দেশের মানুষ নানা পেশা, নানা ধর্ম ও সম্প্রদায়ের। এ দেশে মুসলমান, হিন্দু, বৌদ্ধ, খ্রিস্টান সবাই মিলেমিশে সুখে-শান্তিতে বাস করে।",
          bulletPoints = listOf(
            "ধর্মীয় সম্প্রীতি: মুসলমানদের ঈদ, হিন্দুদের পূজা, বৌদ্ধদের বুদ্ধ পূর্ণিমা, খ্রিস্টানদের বড়দিন।",
            "পয়লা বৈশাখ: বাঙালির সর্বজনীন প্রাণবন্ত বর্ষবরণ উৎসব।",
            "ক্ষুদ্র নৃগোষ্ঠী: চাকমা, মারমা, গারো, সাঁওতাল ইত্যাদি জনগোষ্ঠীর নিজস্ব চমৎকার ভাষা ও সংস্কৃতি রয়েছে।"
          ),
          specialBoxTitle = "মূল ভাবনা",
          specialBoxContent = "সবাই মিলে এক সুতোয় গাঁথা আমাদের এই সোনার বাংলাদেশ। দেশ হলো মায়ের মতো, দেশকে ভালোবাসাই প্রকৃত দেশপ্রেম।"
        )
      ),
      questions = listOf(
        Question(
          id = "c5_ban_1_q1",
          questionText = "বাঙালির সর্বজনীন জাতীয় উৎসব কোনটি?",
          options = listOf("পয়লা বৈশাখ", "বসন্ত উৎসব", "নবান্ন উৎসব", "পৌষ মেলা"),
          correctIndex = 0,
          explanation = "পয়লা বৈশাখ ধর্ম-বর্ণ নির্বিশেষে সকল বাঙালির সবচেয়ে বড় মিলনমেলা।"
        ),
        Question(
          id = "c5_ban_1_q2",
          questionText = "গারো জনগোষ্ঠীর ঐতিহ্যবাহী উৎসবের নাম কী?",
          options = listOf("বিজু", "ওয়ানগালা", "সাংগ্রাই", "বৈসাবি"),
          correctIndex = 1,
          explanation = "গারোদের অন্যতম প্রধান ফসল তোলার উৎসব হলো ওয়ানগালা।"
        ),
        Question(
          id = "c5_ban_1_q3",
          questionText = "'দেশকে ভালোবাসাই দেশপ্রেম' - দেশ আমাদের কার মতো?",
          options = listOf("বন্ধুর মতো", "শিক্ষকের মতো", "মায়ের মতো", "ভাইয়ের মতো"),
          correctIndex = 2,
          explanation = "দেশ আমাদের মায়ের মতো পরম স্নেহে আশ্রয় ও অন্ন দেয়।"
        ),
        Question(
          id = "c5_ban_1_q4",
          questionText = "নিচের কোনটি চাকমাদের নববর্ষ উৎসবের নাম?",
          options = listOf("বিজু", "ওয়ানগালা", "নবান্ন", "ঈদ"),
          correctIndex = 0,
          explanation = "চাকমা জনগোষ্ঠীর জনপ্রিয় তিন দিনের নববর্ষ উৎসবের নাম বিজু।"
        )
      )
    ),

    // 2. Class 5 - English
    Chapter(
      id = "c5_eng_1",
      classGrade = ClassGrade.CLASS_5,
      subjectType = SubjectType.ENGLISH,
      chapterNumberBengali = "Unit 1",
      title = "Hello! & Wh-Questions",
      subtitle = "Greetings, introductions and forming question sentences",
      readingMinutes = 7,
      sections = listOf(
        LessonSection(
          title = "Conversations & Greetings",
          bodyText = "When we meet people, we greet them politely: 'Hello!', 'Good morning!', 'How are you?'",
          bulletPoints = listOf(
            "What: Asking about things. (What is your name?)",
            "Where: Asking about places. (Where are you going?)",
            "When: Asking about time. (When will you return?)",
            "Who: Asking about people. (Who is your class teacher?)",
            "Why: Asking for reasons. (Why are you happy?)",
            "How: Asking about manner or condition. (How do you go to school?)"
          ),
          specialBoxTitle = "Grammar Tip",
          specialBoxContent = "Wh-questions always start with a question word and end with a Question Mark (?)."
        )
      ),
      questions = listOf(
        Question(
          id = "c5_eng_1_q1",
          questionText = "Which Wh-word is used to ask about a place?",
          options = listOf("When", "Where", "Who", "What"),
          correctIndex = 1,
          explanation = "'Where' is used to ask about location or place."
        ),
        Question(
          id = "c5_eng_1_q2",
          questionText = "'_____ is your best friend?' Which word fits best?",
          options = listOf("Who", "Why", "Where", "How"),
          correctIndex = 0,
          explanation = "'Who' is used when asking about a person."
        ),
        Question(
          id = "c5_eng_1_q3",
          questionText = "Choose the correct question punctuation:",
          options = listOf("Where do you live.", "Where do you live!", "Where do you live?", "Where do you live,"),
          correctIndex = 2,
          explanation = "Questions must always conclude with a question mark (?)."
        ),
        Question(
          id = "c5_eng_1_q4",
          questionText = "What is the polite reply to 'How are you?'",
          options = listOf("I am fine, thank you.", "Go away.", "Yes I know.", "My name is Shanto."),
          correctIndex = 0,
          explanation = "'I am fine, thank you.' is the most polite and natural answer."
        )
      )
    ),

    // 3. Class 5 - Math
    Chapter(
      id = "c5_math_1",
      classGrade = ClassGrade.CLASS_5,
      subjectType = SubjectType.MATH,
      chapterNumberBengali = "অধ্যায় ১",
      title = "গড় ও শতকরা হিসাবের নিয়ম",
      subtitle = "বাস্তব জীবনের সমস্যা সমাধানে গড় ও শতকরা নির্ণয়",
      readingMinutes = 8,
      sections = listOf(
        LessonSection(
          title = "গড় কাকে বলে?",
          bodyText = "কতগুলো একই জাতীয় রাশির যোগফলকে রাশিগুলোর মোট সংখ্যা দ্বারা ভাগ করলে যে মান পাওয়া যায়, তাকে গড় বলে।",
          bulletPoints = listOf(
            "গড় = (রাশিগুলোর যোগফল) ÷ (রাশিগুলোর সংখ্যা)",
            "রাশিগুলোর যোগফল = গড় × রাশিগুলোর সংখ্যা"
          ),
          specialBoxTitle = "শতকরা (Percentage)",
          specialBoxContent = "শতকরা হলো এমন একটি অনুপাত বা ভগ্নাংশ যার হর সর্বদা ১০০। একে '%' প্রতীক দ্বারা প্রকাশ করা হয়। যেমন: ২৫% মানে ২৫/১০০ = ১/৪।"
        )
      ),
      questions = listOf(
        Question(
          id = "c5_math_1_q1",
          questionText = "১০, ২০ এবং ৩০ এর গড় কত?",
          options = listOf("১৫", "২০", "২৫", "৬০"),
          correctIndex = 1,
          explanation = "যোগফল = ১০ + ২০ + ৩০ = ৬০। গড় = ৬০ ÷ ৩ = ২০।"
        ),
        Question(
          id = "c5_math_1_q2",
          questionText = "শতকরা চিহ্নের হর সর্বদা কত হয়?",
          options = listOf("১০", "৫০", "১০০", "১০০০"),
          correctIndex = 2,
          explanation = "শতকরা হলো এমন একটি ভগ্নাংশ যার হর সর্বদা ১০০।"
        ),
        Question(
          id = "c5_math_1_q3",
          questionText = "৫০ এর ১০% কত?",
          options = listOf("৫", "১০", "১৫", "২০"),
          correctIndex = 0,
          explanation = "৫০ × (১০/১০০) = ৫।"
        ),
        Question(
          id = "c5_math_1_q4",
          questionText = "৪ জন শিক্ষার্থীর গড় বয়স ১০ বছর হলে তাদের বয়সের সমষ্টি কত?",
          options = listOf("২৫ বছর", "৩০ বছর", "৪০ বছর", "৫০ বছর"),
          correctIndex = 2,
          explanation = "সমষ্টি = গড় × সংখ্যা = ১০ × ৪ = ৪০ বছর।"
        )
      )
    ),

    // 4. Class 5 - Science
    Chapter(
      id = "c5_sci_1",
      classGrade = ClassGrade.CLASS_5,
      subjectType = SubjectType.SCIENCE,
      chapterNumberBengali = "অধ্যায় ১",
      title = "মহাবিশ্ব ও সৌরজগত",
      subtitle = "সূর্য, গ্রহসমূহ, চাঁদের দশা এবং পৃথিবীর আহ্নিক ও বার্ষিক গতি",
      readingMinutes = 8,
      sections = listOf(
        LessonSection(
          title = "সৌরজগত ও এর গ্রহসমূহ",
          bodyText = "সূর্য এবং তার চারদিকে ঘূর্ণায়মান আটটি গ্রহ, উপগ্রহ, গ্রহাণু ও ধুমকেতু নিয়ে আমাদের সৌরজগত গঠিত। সৌরজগতের কেন্দ্রে রয়েছে বিশাল নক্ষত্র সূর্য।",
          bulletPoints = listOf(
            "সূর্য থেকে দূরত্ব অনুযায়ী গ্রহগুলো: বুধ, শুক্র, পৃথিবী, মঙ্গল, বৃহস্পতি, শনি, ইউরেনাস ও নেপচুন।",
            "সৌরজগতের সবচেয়ে বড় গ্রহ: বৃহস্পতি (Jupiter)।",
            "পৃথিবীর একমাত্র প্রাকৃতিক উপগ্রহ: চাঁদ।"
          ),
          specialBoxTitle = "পৃথিবীর গতি",
          specialBoxContent = "আহ্নিক গতির কারণে দিন ও রাত হয় (সময় লাগে ২৪ ঘণ্টা)। বার্ষিক গতির কারণে ঋতু পরিবর্তন হয় (সময় লাগে ৩৬৫ দিন ৬ ঘণ্টা)।"
        )
      ),
      questions = listOf(
        Question(
          id = "c5_sci_1_q1",
          questionText = "সৌরজগতের সবচেয়ে বড় গ্রহ কোনটি?",
          options = listOf("পৃথিবী", "মঙ্গল", "বৃহস্পতি", "শনি"),
          correctIndex = 2,
          explanation = "সৌরজগতের সর্ববৃহৎ গ্রহ হলো বৃহস্পতি।"
        ),
        Question(
          id = "c5_sci_1_q2",
          questionText = "পৃথিবীর কোন গতির কারণে দিন ও রাত হয়?",
          options = listOf("বার্ষিক গতি", "আহ্নিক গতি", "ঘূর্ণন গতি", "চন্দ্রগতি"),
          correctIndex = 1,
          explanation = "পৃথিবীর নিজ অক্ষের ওপর ২৪ ঘণ্টার আহ্নিক গতির ফলে দিন এবং রাত সংঘটিত হয়।"
        ),
        Question(
          id = "c5_sci_1_q3",
          questionText = "পৃথিবীর একমাত্র প্রাকৃতিক উপগ্রহ কোনটি?",
          options = listOf("সূর্য", "চাঁদ", "মঙ্গল", "ধ্রুবতারা"),
          correctIndex = 1,
          explanation = "চাঁদ হলো পৃথিবীর একমাত্র প্রাকৃতিক উপগ্রহ।"
        ),
        Question(
          id = "c5_sci_1_q4",
          questionText = "সৌরজগতে মোট কয়টি গ্রহ রয়েছে?",
          options = listOf("৭টি", "৮টি", "৯টি", "১০টি"),
          correctIndex = 1,
          explanation = "বর্তমানে সৌরজগতে মোট ৮টি স্বীকৃত গ্রহ রয়েছে।"
        )
      )
    )
  )

  fun getChapters(grade: ClassGrade, subject: SubjectType): List<Chapter> {
    return chapters.filter { it.classGrade == grade && it.subjectType == subject }
  }

  fun getChapterById(id: String): Chapter? {
    return chapters.find { it.id == id }
  }
}
