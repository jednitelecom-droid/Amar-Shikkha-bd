package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [QuizAttemptEntity::class, StudentProfileEntity::class],
  version = 1,
  exportSchema = false
)
abstract class ShikkhaDatabase : RoomDatabase() {
  abstract fun shikkhaDao(): ShikkhaDao

  companion object {
    @Volatile
    private var INSTANCE: ShikkhaDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): ShikkhaDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ShikkhaDatabase::class.java,
          "amar_shikkha_database"
        )
          .addCallback(object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              scope.launch {
                INSTANCE?.shikkhaDao()?.insertOrUpdateProfile(
                  StudentProfileEntity(
                    id = 1,
                    studentName = "সোহান আহমেদ",
                    className = "৩য় শ্রেণি",
                    rollNumber = "০৫",
                    schoolName = "সরকারি প্রাথমিক বিদ্যালয়",
                    avatarId = 0,
                    totalPoints = 80,
                    starsCount = 12
                  )
                )
              }
            }
          })
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
