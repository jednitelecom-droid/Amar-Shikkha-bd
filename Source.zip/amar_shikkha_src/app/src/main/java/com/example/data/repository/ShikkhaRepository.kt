package com.example.data.repository

import com.example.data.local.QuizAttemptEntity
import com.example.data.local.ShikkhaDao
import com.example.data.local.StudentProfileEntity
import kotlinx.coroutines.flow.Flow

class ShikkhaRepository(private val dao: ShikkhaDao) {

  val allAttempts: Flow<List<QuizAttemptEntity>> = dao.getAllQuizAttempts()

  val studentProfile: Flow<StudentProfileEntity?> = dao.getStudentProfile()

  fun getRecentAttempts(limit: Int): Flow<List<QuizAttemptEntity>> = dao.getRecentQuizAttempts(limit)

  fun getAttemptsForChapter(chapterId: String): Flow<List<QuizAttemptEntity>> = dao.getAttemptsForChapter(chapterId)

  suspend fun saveQuizResult(attempt: QuizAttemptEntity): Long {
    val id = dao.insertQuizAttempt(attempt)
    // Award points based on percentage
    val earnedPoints = attempt.percentage / 10 * 10
    val earnedStars = if (attempt.percentage >= 80) 3 else if (attempt.percentage >= 50) 2 else 1
    dao.addPointsAndStars(earnedPoints, earnedStars)
    return id
  }

  suspend fun saveProfile(profile: StudentProfileEntity) {
    dao.insertOrUpdateProfile(profile)
  }

  suspend fun clearHistory() {
    dao.clearAllHistory()
  }
}
