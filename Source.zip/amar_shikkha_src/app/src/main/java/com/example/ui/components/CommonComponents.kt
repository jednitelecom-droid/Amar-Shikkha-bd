package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Screen
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShikkhaTopAppBar(
  title: String,
  showBackButton: Boolean = false,
  onBackClick: () -> Unit = {},
  onProfileClick: () -> Unit = {},
  studentName: String = "",
  modifier: Modifier = Modifier
) {
  TopAppBar(
    modifier = modifier,
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.surface,
      titleContentColor = MaterialTheme.colorScheme.onSurface
    ),
    title = {
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        if (studentName.isNotBlank() && !showBackButton) {
          Text(
            text = "স্বাগতম, $studentName!",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }
    },
    navigationIcon = {
      if (showBackButton) {
        IconButton(
          onClick = onBackClick,
          modifier = Modifier.testTag("top_bar_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "ফিরে যান"
          )
        }
      }
    },
    actions = {
      if (!showBackButton) {
        Box(
          modifier = Modifier
            .padding(end = 12.dp)
            .size(40.dp)
            .clip(CircleShape)
            .background(EmeraldPrimary.copy(alpha = 0.15f))
            .clickable(onClick = onProfileClick)
            .testTag("top_bar_profile_avatar"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "প্রোফাইল",
            tint = EmeraldPrimary,
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }
  )
}

@Composable
fun ShikkhaBottomNavBar(
  currentScreen: Screen,
  onNavigate: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  NavigationBar(
    modifier = modifier,
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    NavigationBarItem(
      selected = currentScreen is Screen.Home,
      onClick = { onNavigate(Screen.Home) },
      icon = { Icon(Icons.Default.Home, contentDescription = "হোম") },
      label = { Text("হোম") },
      modifier = Modifier.testTag("nav_item_home"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = EmeraldPrimary,
        selectedTextColor = EmeraldPrimary,
        indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
      )
    )

    NavigationBarItem(
      selected = currentScreen is Screen.ExamHistory,
      onClick = { onNavigate(Screen.ExamHistory) },
      icon = { Icon(Icons.Default.History, contentDescription = "ফলাফল তালিকা") },
      label = { Text("ইতিহাস") },
      modifier = Modifier.testTag("nav_item_history"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = EmeraldPrimary,
        selectedTextColor = EmeraldPrimary,
        indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
      )
    )

    NavigationBarItem(
      selected = currentScreen is Screen.Profile,
      onClick = { onNavigate(Screen.Profile) },
      icon = { Icon(Icons.Default.Person, contentDescription = "প্রোফাইল") },
      label = { Text("প্রোফাইল") },
      modifier = Modifier.testTag("nav_item_profile"),
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = EmeraldPrimary,
        selectedTextColor = EmeraldPrimary,
        indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
      )
    )
  }
}

@Composable
fun GradeBadge(
  grade: String,
  modifier: Modifier = Modifier,
  backgroundColor: Color = AmberSecondary
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(backgroundColor)
      .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = grade,
      color = Color.White,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp
    )
  }
}

@Composable
fun StatCard(
  title: String,
  value: String,
  icon: ImageVector,
  iconTint: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    )
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(iconTint.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = value,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = title,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
