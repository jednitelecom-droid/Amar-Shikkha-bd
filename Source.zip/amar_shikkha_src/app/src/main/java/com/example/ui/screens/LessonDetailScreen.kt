package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BengaliUtils
import com.example.model.Chapter
import com.example.ui.ShikkhaViewModel
import com.example.ui.theme.AmberDark
import com.example.ui.theme.AmberLight

@Composable
fun LessonDetailScreen(
  viewModel: ShikkhaViewModel,
  onStartQuiz: (Chapter) -> Unit,
  modifier: Modifier = Modifier
) {
  val chapter by viewModel.selectedChapter.collectAsStateWithLifecycle()

  if (chapter == null) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("কোনো পাঠ পাওয়া যায়নি")
    }
    return
  }

  val currentChapter = chapter!!

  Column(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
    ) {
      // Header Info Card
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = currentChapter.subjectType.lightColor),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("lesson_header")
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(currentChapter.subjectType.primaryColor)
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "${currentChapter.classGrade.banglaName} • ${currentChapter.chapterNumberBengali}",
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  Icons.Default.AccessTime,
                  contentDescription = null,
                  tint = currentChapter.subjectType.primaryColor,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${BengaliUtils.toBengaliNumber(currentChapter.readingMinutes)} মিনিট",
                  style = MaterialTheme.typography.bodySmall,
                  color = currentChapter.subjectType.primaryColor,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = currentChapter.title,
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )

            Text(
              text = currentChapter.subtitle,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Lesson Sections
      items(currentChapter.sections) { section ->
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Text(
              text = section.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = currentChapter.subjectType.primaryColor
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = section.bodyText,
              style = MaterialTheme.typography.bodyLarge,
              lineHeight = 24.sp,
              color = MaterialTheme.colorScheme.onSurface
            )

            if (section.bulletPoints.isNotEmpty()) {
              Spacer(modifier = Modifier.height(12.dp))
              section.bulletPoints.forEach { point ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  Box(
                    modifier = Modifier
                      .padding(top = 6.dp)
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(currentChapter.subjectType.primaryColor)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = point,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 22.sp
                  )
                }
              }
            }

            if (section.specialBoxTitle != null && section.specialBoxContent != null) {
              Spacer(modifier = Modifier.height(14.dp))
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = AmberLight.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.Top
                ) {
                  Icon(
                    Icons.Default.Lightbulb,
                    contentDescription = null,
                    tint = AmberDark,
                    modifier = Modifier.size(22.dp)
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = section.specialBoxTitle,
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = AmberDark
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = section.specialBoxContent,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // Bottom Sticky CTA for Quiz
    Surface(
      shadowElevation = 8.dp,
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth()
    ) {
      Box(modifier = Modifier.padding(16.dp)) {
        Button(
          onClick = { onStartQuiz(currentChapter) },
          colors = ButtonDefaults.buttonColors(containerColor = currentChapter.subjectType.primaryColor),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("lesson_take_quiz_button")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "অধ্যায়ের কুইজ শুরু করুন (${BengaliUtils.toBengaliNumber(currentChapter.questions.size)}টি প্রশ্ন)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
