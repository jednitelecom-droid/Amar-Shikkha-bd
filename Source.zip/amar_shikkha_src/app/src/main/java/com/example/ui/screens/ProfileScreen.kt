package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.StudentProfileEntity
import com.example.model.BengaliUtils
import com.example.ui.ShikkhaViewModel
import com.example.ui.components.StatCard
import com.example.ui.theme.AmberDark
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SkyTertiary
import com.example.ui.theme.SuccessGreen

private val avatarEmojis = listOf("👦", "👧", "🧑‍🎓", "👩‍🎓", "🦁", "🚀")

@Composable
fun ProfileScreen(
  viewModel: ShikkhaViewModel,
  modifier: Modifier = Modifier
) {
  val profileState by viewModel.studentProfile.collectAsStateWithLifecycle()
  val attempts by viewModel.allQuizAttempts.collectAsStateWithLifecycle()

  val profile = profileState ?: StudentProfileEntity()

  var isEditing by remember { mutableStateOf(false) }

  var editName by remember(profile) { mutableStateOf(profile.studentName) }
  var editClass by remember(profile) { mutableStateOf(profile.className) }
  var editRoll by remember(profile) { mutableStateOf(profile.rollNumber) }
  var editSchool by remember(profile) { mutableStateOf(profile.schoolName) }
  var editAvatarIndex by remember(profile) { mutableIntStateOf(profile.avatarId) }

  val totalTests = attempts.size
  val avgScore = if (totalTests > 0) attempts.map { it.percentage }.average().toInt() else 0
  val hasPerfectScore = attempts.any { it.percentage == 100 }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
  ) {
    // 1. Profile Hero Card
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("student_profile_card")
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            IconButton(
              onClick = { isEditing = true },
              modifier = Modifier.testTag("edit_profile_button")
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "প্রোফাইল পরিবর্তন করুন",
                tint = EmeraldPrimary
              )
            }
          }

          // Avatar Box
          val currentEmoji = avatarEmojis.getOrElse(profile.avatarId) { "🧑‍🎓" }
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(listOf(EmeraldPrimary, EmeraldDark))
              ),
            contentAlignment = Alignment.Center
          ) {
            Text(text = currentEmoji, fontSize = 42.sp)
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = profile.studentName,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "${profile.className} • রোল: ${profile.rollNumber}",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = EmeraldPrimary
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = profile.schoolName,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // 2. Study Overview Statistics
    item {
      Column {
        Text(
          text = "শিক্ষার্থীর অর্জন ও পরিসংখ্যান",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "মোট পরীক্ষা",
            value = BengaliUtils.toBengaliNumber(totalTests),
            icon = Icons.Default.EmojiEvents,
            iconTint = AmberSecondary,
            modifier = Modifier.weight(1f)
          )

          StatCard(
            title = "গড় সাফল্য",
            value = BengaliUtils.toBengaliPercent(avgScore),
            icon = Icons.Default.Star,
            iconTint = EmeraldPrimary,
            modifier = Modifier.weight(1f)
          )

          StatCard(
            title = "মোট পয়েন্ট",
            value = BengaliUtils.toBengaliNumber(profile.totalPoints),
            icon = Icons.Default.Verified,
            iconTint = SkyTertiary,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // 3. Badges & Medals Section
    item {
      Column {
        Text(
          text = "অর্জিত ব্যাজ ও মেডেল",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          BadgeItem(
            title = "প্রথম কুইজ বিজয়ী",
            description = "অ্যাপে যেকোনো একটি অধ্যায়ের কুইজ সম্পন্ন করেছো",
            isUnlocked = totalTests >= 1,
            icon = "🥇"
          )

          BadgeItem(
            title = "শতভাগ নির্ভুল প্রস্তুতি",
            description = "যেকোনো একটি পরীক্ষায় ১০০% নম্বর পেয়েছো",
            isUnlocked = hasPerfectScore,
            icon = "🌟"
          )

          BadgeItem(
            title = "কুইজ মাস্টার",
            description = "কমপক্ষে ৩টি ভিন্ন কুইজ পরীক্ষা সম্পন্ন করেছো",
            isUnlocked = totalTests >= 3,
            icon = "🏆"
          )

          BadgeItem(
            title = "জ্ঞান সাধক",
            description = "অ্যাপ থেকে ১০০ এর বেশি মেধা পয়েন্ট অর্জন করেছো",
            isUnlocked = profile.totalPoints >= 100,
            icon = "🎖️"
          )
        }
      }
    }
  }

  // Edit Profile Dialog
  if (isEditing) {
    AlertDialog(
      onDismissRequest = { isEditing = false },
      title = {
        Text(
          text = "প্রোফাইল তথ্য হালনাগাদ",
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          // Choose Avatar
          Text(
            text = "অবয়ব (Avatar) নির্বাচন করুন:",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            avatarEmojis.forEachIndexed { index, emoji ->
              val isSelected = editAvatarIndex == index
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(if (isSelected) EmeraldPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
                  .border(
                    width = if (isSelected) 2.dp else 0.dp,
                    color = if (isSelected) EmeraldPrimary else Color.Transparent,
                    shape = CircleShape
                  )
                  .clickable { editAvatarIndex = index },
                contentAlignment = Alignment.Center
              ) {
                Text(text = emoji, fontSize = 22.sp)
              }
            }
          }

          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("শিক্ষার্থীর নাম") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = editClass,
            onValueChange = { editClass = it },
            label = { Text("শ্রেণি (যেমন: ১ম, ২য়, ৩য়, ৪র্থ, ৫ম)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = editRoll,
            onValueChange = { editRoll = it },
            label = { Text("রোল নম্বর") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = editSchool,
            onValueChange = { editSchool = it },
            label = { Text("বিদ্যালয়ের নাম") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.updateProfile(
              name = editName,
              className = editClass,
              roll = editRoll,
              school = editSchool,
              avatarId = editAvatarIndex
            )
            isEditing = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
        ) {
          Text("সংরক্ষণ করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { isEditing = false }) {
          Text("বাতিল")
        }
      }
    )
  }
}

@Composable
fun BadgeItem(
  title: String,
  description: String,
  isUnlocked: Boolean,
  icon: String
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isUnlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ),
    border = if (isUnlocked) BorderStroke(1.dp, AmberSecondary.copy(alpha = 0.5f)) else null,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(
            if (isUnlocked) AmberSecondary.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(text = icon, fontSize = 24.sp)
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
          )
          if (isUnlocked) {
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              Icons.Default.Verified,
              contentDescription = "অর্জিত",
              tint = EmeraldPrimary,
              modifier = Modifier.size(16.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(
            if (isUnlocked) SuccessGreen.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
          )
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text(
          text = if (isUnlocked) "অর্জিত" else "লক করা",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = if (isUnlocked) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
