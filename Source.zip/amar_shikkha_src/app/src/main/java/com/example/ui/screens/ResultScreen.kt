package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BengaliUtils
import com.example.ui.ShikkhaViewModel
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen

@Composable
fun ResultScreen(
  viewModel: ShikkhaViewModel,
  onRetryQuiz: () -> Unit,
  onBackToHome: () -> Unit,
  onBackToChapters: () -> Unit,
  modifier: Modifier = Modifier
) {
  val quizState by viewModel.quizState.collectAsStateWithLifecycle()
  val summary = quizState.resultSummary
  val chapter = quizState.chapter

  if (summary == null || chapter == null) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("ফলাফলের তথ্য পাওয়া যায়নি")
    }
    return
  }

  val optionLabels = listOf("ক", "খ", "গ", "ঘ")

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
  ) {
    // 1. Grand Result Celebration Hero
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("result_celebration_card")
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Trophy Badge
          Box(
            modifier = Modifier
              .size(64.dp)
              .clip(CircleShape)
              .background(
                if (summary.percentage >= 60) AmberSecondary.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = if (summary.percentage >= 60) Icons.Default.EmojiEvents else Icons.Default.Star,
              contentDescription = null,
              tint = if (summary.percentage >= 60) AmberSecondary else MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(38.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "পরীক্ষার ফলাফল",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )

          Text(
            text = "${summary.classGrade.banglaName} • ${summary.chapterTitle}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Percentage & Grade Circle
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Box(
              modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(
                  Brush.linearGradient(
                    listOf(
                      if (summary.percentage >= 80) EmeraldPrimary else if (summary.percentage >= 50) AmberSecondary else ErrorRed,
                      if (summary.percentage >= 80) EmeraldDark else if (summary.percentage >= 50) AmberSecondary.copy(alpha = 0.8f) else ErrorRed.copy(alpha = 0.8f)
                    )
                  )
                ),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = BengaliUtils.toBengaliPercent(summary.percentage),
                  style = MaterialTheme.typography.headlineMedium,
                  color = Color.White,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "গ্রেড: ${summary.gradeLetter}",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color.White.copy(alpha = 0.9f),
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = summary.gradeTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (summary.percentage >= 60) EmeraldDark else ErrorRed
          )
        }
      }
    }

    // 2. Score Breakdown Grid
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Total
        ScoreMetricCard(
          title = "মোট প্রশ্ন",
          value = BengaliUtils.toBengaliNumber(summary.totalQuestions),
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.weight(1f)
        )
        // Correct
        ScoreMetricCard(
          title = "সঠিক উত্তর",
          value = BengaliUtils.toBengaliNumber(summary.correctCount),
          color = SuccessGreen,
          modifier = Modifier.weight(1f)
        )
        // Wrong
        ScoreMetricCard(
          title = "ভুল উত্তর",
          value = BengaliUtils.toBengaliNumber(summary.wrongCount),
          color = ErrorRed,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 3. Question-by-Question Review Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "উত্তরপত্র ও সমাধান পর্যালোচনা",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // 4. Detailed Questions Review List
    itemsIndexed(chapter.questions) { index, question ->
      val userSelectedOptionIndex = summary.userSelectedAnswers[index]
      val isCorrect = userSelectedOptionIndex == question.correctIndex

      OutlinedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.outlinedCardColors(
          containerColor = if (isCorrect) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
        ),
        border = BorderStroke(
          1.dp,
          if (isCorrect) SuccessGreen.copy(alpha = 0.4f) else ErrorRed.copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .clip(CircleShape)
                  .background(if (isCorrect) SuccessGreen else ErrorRed),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = if (isCorrect) Icons.Default.Check else Icons.Default.Close,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "প্রশ্ন ${BengaliUtils.toBengaliNumber(index + 1)}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = if (isCorrect) SuccessGreen else ErrorRed
              )
            }

            Text(
              text = if (isCorrect) "+১ নম্বর" else "+০ নম্বর",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold,
              color = if (isCorrect) SuccessGreen else ErrorRed
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = question.questionText,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(10.dp))

          // User's answer vs correct answer
          val userOptionText = userSelectedOptionIndex?.let {
            "${optionLabels.getOrElse(it) { "" }}) ${question.options.getOrElse(it) { "" }}"
          } ?: "উত্তর দেওয়া হয়নি"

          val correctOptionText = "${optionLabels.getOrElse(question.correctIndex) { "" }}) ${question.options[question.correctIndex]}"

          Text(
            text = "তোমার উত্তর: $userOptionText",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (isCorrect) SuccessGreen else ErrorRed
          )

          if (!isCorrect) {
            Text(
              text = "সঠিক উত্তর ছিল: $correctOptionText",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = SuccessGreen
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "💡 সমাধান: ${question.explanation}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      }
    }

    // 5. Action Buttons
    item {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onRetryQuiz,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("retry_quiz_button")
        ) {
          Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("আবার পরীক্ষা দিন")
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = onBackToChapters,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("back_to_chapters_button")
          ) {
            Text("অধ্যায়ের তালিকা")
          }

          Button(
            onClick = onBackToHome,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("result_home_button")
          ) {
            Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("হোমে যান")
          }
        }
      }
    }
  }
}

@Composable
fun ScoreMetricCard(
  title: String,
  value: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = color
      )
      Text(
        text = title,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
