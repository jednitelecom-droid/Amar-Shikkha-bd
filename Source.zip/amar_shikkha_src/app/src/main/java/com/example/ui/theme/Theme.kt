package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = EmeraldLight,
  onPrimary = Color(0xFF003833),
  primaryContainer = EmeraldDark,
  onPrimaryContainer = EmeraldContainer,
  secondary = AmberLight,
  onSecondary = Color(0xFF451E00),
  secondaryContainer = AmberDark,
  onSecondaryContainer = AmberContainer,
  tertiary = SkyLight,
  onTertiary = Color(0xFF003554),
  tertiaryContainer = SkyDark,
  onTertiaryContainer = SkyContainer,
  background = BackgroundDark,
  onBackground = Color(0xFFE2E8F0),
  surface = SurfaceDark,
  onSurface = Color(0xFFE2E8F0),
  surfaceVariant = SurfaceVariantDark,
  onSurfaceVariant = Color(0xFFCBD5E1),
  outline = OutlineDark
)

private val LightColorScheme = lightColorScheme(
  primary = EmeraldPrimary,
  onPrimary = Color.White,
  primaryContainer = EmeraldContainer,
  onPrimaryContainer = OnEmeraldContainer,
  secondary = AmberSecondary,
  onSecondary = Color.White,
  secondaryContainer = AmberContainer,
  onSecondaryContainer = OnAmberContainer,
  tertiary = SkyTertiary,
  onTertiary = Color.White,
  tertiaryContainer = SkyContainer,
  onTertiaryContainer = OnSkyContainer,
  background = BackgroundLight,
  onBackground = Color(0xFF0F172A),
  surface = SurfaceLight,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = SurfaceVariantLight,
  onSurfaceVariant = Color(0xFF475569),
  outline = OutlineLight
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep educational palette consistent
  content: @Composable () -> Unit
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    content = content
  )
}
